# standardize_country
Package that provides dictionaries for standardizing country names into ISO-2 and ISO-3 format; continously updated
